<?php

#=========================================================================================================================#

namespace GiftCode;

#=========================================================================================================================#

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\event\player\{PlayerDropItemEvent, PlayerInteractEvent, PlayerItemHeldEvent, PlayerJoinEvent, PlayerChatEvent};
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\utils\Config;

#=========================================================================================================================#

use pocketmine\event\player\PlayerQuitEvent;

#=========================================================================================================================#

use GiftCode\FormEvent\Form;
use GiftCode\FormEvent\CustomForm;

#=========================================================================================================================#

use onebone\economyapi\EconomyAPI;

#=========================================================================================================================#

class Main extends PluginBase implements Listener {

#=========================================================================================================================#

    public $used;
    public $eco;
    public $giftcode;
    public $instance;
    public $formCount = 0;
    public $forms = [];

#=========================================================================================================================#

    public function onEnable() {
     $this->getLogger()->info("Plugin Giftcode làm lại bởi ZulfahmiFjr");
	 $this->getLogger()->info("§aGiftcode[việt hóa] v1 đã được bật!");
	 $this->getLogger()->info("§aPlugin được dịch bởi Sói");
	 $this->user = new Config($this->getDataFolder() . "user.yml", Config::YAML);
     $plugin = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");
     if(is_null($plugin)) {
      $this->getLogger()->info("Vui lòng cài đặt plugin EconomyAPI!");
     $this->getServer()->shutdown();
     }else{
      $this->eco = EconomyAPI::getInstance();
     }
     $this->formCount = rand(0, 0xFFFFFFFF);
     $this->getServer()->getPluginManager()->registerEvents($this, $this);
     if(!is_dir($this->getDataFolder())) {
      mkdir($this->getDataFolder());
     }
     $this->used = new \SQLite3($this->getDataFolder() ."used-code.db");
     $this->used->exec("CREATE TABLE IF NOT EXISTS code (code);");
     $this->giftcode = new \SQLite3($this->getDataFolder() ."code.dn");
     $this->giftcode->exec("CREATE TABLE IF NOT EXISTS code (code);");
     }

#=========================================================================================================================#

    public function onJoin(PlayerJoinEvent $ev){
		$p = $ev->getPlayer()->getName();
			if(!($this->user->exists(strtolower($p)))){
				$this->getLogger()->notice(" Không tìm thấy dữ liệu $p ");
				$this->getLogger()->notice(" Tạo dữ liệu $p ");
				$code = $this->createCode();
				$this->user->set(strtolower($p), ["redeem" => true, "code" => $code]);
				$this->user->save();
		}
	}
#=========================================================================================================================#

    public function createCode() {
     $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
     $charactersLength = strlen($characters);
     $length = 5;
     $randomString = '';
     for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
     }
     return $randomString;
     }

#=========================================================================================================================#
    public function createCustomForm(callable $function = null) : CustomForm {
     $this->formCountBump();
     $form = new CustomForm($this->formCount, $function);
     $this->forms[$this->formCount] = $form;
     return $form;
    }

#=========================================================================================================================#

    public function formCountBump() : void {
     ++$this->formCount;
     if($this->formCount & (1 << 32)){
      $this->formCount = rand(0, 0xFFFFFFFF);
     }
  }

#=========================================================================================================================#

    public function onPacketReceived(DataPacketReceiveEvent $ev) : void {
     $pk = $ev->getPacket();
     if($pk instanceof ModalFormResponsePacket){
      $player = $ev->getPlayer();
      $formId = $pk->formId;
      $data = json_decode($pk->formData, true);
      if(isset($this->forms[$formId])){
       $form = $this->forms[$formId];
       if(!$form->isRecipient($player)){
        return;
       }
       $callable = $form->getCallable();
       if(!is_array($data)){
        $data = [$data];
       }
       if($callable !== null) {
        $callable($ev->getPlayer(), $data);
       }
       unset($this->forms[$formId]);
       $ev->setCancelled();
       }
    }
 }

#=========================================================================================================================#

    public function onPlayerQuit(PlayerQuitEvent $ev) {
     $player = $ev->getPlayer();
     foreach ($this->forms as $id => $form) {
      if($form->isRecipient($player)) {
       unset($this->forms[$id]);
       break;
      }
   }
}

#=========================================================================================================================#
    public function DoiCodeTanThu($player){
	$p = $player->getName();
	$form = $this->createCustomForm(function(Player $player, array $data){
		$p = $player->getName();
		$result = $data[0];
		if($result === null){
			$player->sendMessage("§f§l[§r§eGiftCode§r§f§l] §r§6§o Bạn đã không nhập code§r§f!");
		}else{
			if($result === $this->user->get(strtolower($p))["code"]){
				 if($this->user->get(strtolower($p))["redeem"] == true){
				 $inv = $player->getInventory(); 
				 $this->eco->addMoney($player->getName(), 50000);
				 $item = Item::get(57, 0, 64);
				 $item2 = Item::get(41, 0, 64);
				 $item3 = Item::get(42, 0, 64);
				 $item4 = Item::get(133, 0, 64);
				 $inv->addItem($item);
				 $inv->addItem($item2);
				 $inv->addItem($item3);
				 $inv->addItem($item4);
				 $code = $this->user->get(strtolower($p))["code"];
				 $this->user->set(strtolower($p), ["redeem" => false, "code" => $code]);
				 $this->user->save();
				 $player->sendMessage("§f§l[§r§eGiftCode§r§f§l]§r§aBạn đã nhận quà tân thủ");
					 }else{
						 $player->sendMessage("§f§l[§r§eGiftCode§r§f§l] §r§cQuà tân thủ chỉ có thể nhận một lần");
					 }
	 }
		}
		});
		$form->setTitle("§r§f§l-=§eMenu Đổi Giftcode Tân Thủ§r§l§f=-");
		$form->addInput("§6§oNhập mã bạn muốn đổi vào cột bên dưới§r§f!");
		$form->sendToPlayer($player);
}
#=========================================================================================================================#
    public function RedeemMenu($player){
	$p = $player->getName();
     if($player instanceof Player){
      $form = $this->createCustomForm(function(Player $player, array $data){
      $result = $data[0];
      if($result != null){
       if($this->codeExists($this->giftcode, $result)) {
        if(!($this->codeExists($this->used, $result))) {
         $chance = mt_rand(1, 5);
         $this->addCode($this->used, $result);
         switch($chance) {
         default:
          $player->sendMessage("§f§l[§r§eGiftCode§r§f§l]§r§6§o Bạn đã đổi giftcode thành công và nhận được quà tặng là§r§f 200.000$");
          $this->eco->addMoney($player->getName(), 200000);
          break;
        }
     }else{
       $player->sendMessage("§f§l[§r§eGiftCode§r§f§l]§r§6§o Giftcode này đã được sử dụng, hãy nhập mã quà khác§r§f!");
        return true;
       }
    }else{
      $player->sendMessage("§f§l[§r§eGiftCode§r§f§l]§r§6§o Không tìm thấy mã quà tặng, rất tiếc§r§f!");
      return true;
     }
  }else{
    $player->sendMessage("§f§l[§r§eGiftCode§r§f§l]§r§6§o Bạn đã không nhập code§r§f!");
    return true;
   }
});
$form->setTitle("§r§f§l-=§eMenu Đổi Giftcode§r§l§f=-");
$form->addInput("§6§oNhập mã bạn muốn đổi vào cột bên dưới§r§f!");
$form->sendToPlayer($player);
}
}

#=========================================================================================================================#

    public static function getInstance() {
     return $this;
    }

#=========================================================================================================================#

    public function generateCode() {
     $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
     $charactersLength = strlen($characters);
     $length = 10;
     $randomString = '';
     for ($i = 0; $i < $length; $i++) {
      $randomString .= $characters[rand(0, $charactersLength - 1)];
     }
     $this->addCode($this->giftcode, $randomString);
     return $randomString;
     }

#=========================================================================================================================#

     public function codeExists($file, $code) {
      $query = $file->query("SELECT * FROM code WHERE code='$code';");
      $ar = $query->fetchArray(SQLITE3_ASSOC);
      if(!empty($ar)) {
       return true;
      } else {
         return false;
        }
     }

#=========================================================================================================================#

    public function addCode($file, $code) {
     $stmt = $file->prepare("INSERT OR REPLACE INTO code (code) VALUES (:code);");
     $stmt->bindValue(":code", $code);
     $stmt->execute();
    }

#=========================================================================================================================#

    public function onCommand(CommandSender $player, Command $command, string $label, array $args): bool{
     switch($command->getName()){
      case "taocode";
       if($player->isOp()) {
        $code = $this->generateCode();
        $player->sendMessage ("§f§l[§r§eGiftCode§r§f§l]§r§6§o Tạo thành công! Mã là§r§f: " . $code);
       }else{
         $player->sendMessage ("§f§l[§r§eGiftCode§r§f§l]§r§6§o Xin lỗi nhưng mà bạn không phải là OP§r§f!");
        }
        break;

      case "doicode";
       if($player instanceof Player){
        $this->RedeemMenu($player);
       }else{
         $player->sendMessage("§f§l[§r§eGiftCode§r§f§l]§r§6§o Vui lòng sử dụng lệnh này trong trò chơi§r§f!");
        }
		break;
	 case "doicodetanthu";
       if($player instanceof Player){
        $this->DoiCodeTanThu($player);
       }else{
         $player->sendMessage("§f§l[§r§eGiftCode§r§f§l]§r§6§o Vui lòng sử dụng lệnh này trong trò chơi§r§f!");
        }
		break;
	  case "code";
       if($player instanceof Player){
		   $p = $player->getName();
		   $code = $this->user->get(strtolower($p))["code"];
		 if($this->user->get(strtolower($p))["redeem"] == true){
			$player->sendMessage("§f§l[§r§eGiftCode§r§f§l] §6§o Code tân thủ: ".$code." §l§a(chưa dùng)");
		 }else{
			$player->sendMessage("§f§l[§r§eGiftCode§r§f§l] §6§o Code tân thủ: ".$code." §l§c(đã dùng)");
		 }
       }else{
         $player->sendMessage("§f§l[§r§eGiftCode§r§f§l]§r§6§o Vui lòng sử dụng lệnh này trong trò chơi§r§f!");
        }
		break;
     }
     return true;
     }
  }

#=========================================================================================================================#